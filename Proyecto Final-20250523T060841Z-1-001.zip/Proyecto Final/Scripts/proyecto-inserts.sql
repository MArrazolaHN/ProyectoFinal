INSERT INTO Alumno (nombre, apellido, telefono, correo) VALUES
('Carlos', 'Gomez', '123456789', 'carlos.gomez@email.com'),
('Ana', 'Perez', '987654321', 'ana.perez@email.com'),
('Luis', 'Martinez', '564738291', 'luis.martinez@email.com'),
('Sofia', 'Rodriguez', '876543210', 'sofia.rodriguez@email.com'),
('Marcos', 'Lopez', '432198765', 'marcos.lopez@email.com'),
('Marta', 'Diaz', '345678912', 'marta.diaz@email.com'),
('Juan', 'Fernandez', '213546879', 'juan.fernandez@email.com'),
('Laura', 'Sanchez', '908172635', 'laura.sanchez@email.com'),
('Pedro', 'Jimenez', '102938475', 'pedro.jimenez@email.com'),
('Isabel', 'Morales', '120938475', 'isabel.morales@email.com');

INSERT INTO Instructor (nombre, apellido, telefono, correo) VALUES
('Miguel', 'Garcia', '543216789', 'miguel.garcia@email.com'),
('Elena', 'Hernandez', '654321987', 'elena.hernandez@email.com'),
('Luis', 'Alvarez', '112233445', 'luis.alvarez@email.com'),
('Carmen', 'Jimenez', '998877665', 'carmen.jimenez@email.com'),
('David', 'Castro', '887766554', 'david.castro@email.com');

INSERT INTO Pregunta (enunciado) VALUES
('¿Es aconsejable conducir un turismo calzado con unas chanclas?'),
('¿Puede realizar un cambio de sentido en un lugar donde esté prohibido adelantar?'),
('En un vehículo de autoescuela realizando clases prácticas, ¿quién es considerado el conductor?'),
('¿Dónde está permitido que viaje un niño que no alcance los 135 centímetros de estatura?'),
('Con esta señalización, ¿a qué velocidad debe circular?'),
('Una línea blanca continua sobre la calzada, sensiblemente más ancha que en el caso general...'),
('¿Cuál es la sanción por no tener el seguro obligatorio del vehículo?'),
('¿Al aumentar la velocidad incrementa la probabilidad de muerte en caso de atropello a un peatón?'),
('¿Cuántos espejos retrovisores tienen que llevar instalados las motocicletas?'),
('¿Está permitida la circulación de animales por una carretera convencional?'),
('¿Qué aportan a la seguridad vial los sistemas avanzados de ayuda a la conducción también conocidos como ADAS?'),
('¿Cuál es la tasa de alcohol máxima permitida a un conductor novel?'),
('Cuando un vehículo accidentado comienza a arder, ¿qué se debe hacer primero?'),
('En esta situación, ¿qué debe hacer si va a girar a la izquierda?'),
('¿Está permitido colocar la señal luminosa de señalizacion de peligro, V-16, alejada del vehículo averiado?'),
('Para entrar en una autopista, ¿a qué velocidad debe circular?'),
('¿Qué es una detención?'),
('Esta señal indica peligro por la proximidad de...'),
('En condiciones normales, la velocidad adecuada está siempre...'),
('¿Tiene alguna obligación cuando su vehículo va a ser adelantado?'),
('¿Qué distancia de separación respecto al vehículo que le precede deberá mantener un vehículo de más de 3.500 kg. de MMA, circulando por una autovía?'),
('El funcionamiento del airbag, ¿puede llegar a ser peligroso en un accidente?'),
('¿Cuál debe ser su comportamiento al ceder el paso?'),
('En esta vía de poblado, ¿a qué velocidad como máximo podremos circular en ausencia de señalización específica?'),
('La fatiga, ¿provoca lentitud y falta de precisión en los movimientos?'),
('Si los paneles de mensaje variable indican que los turismos con distintivo ambiental B pueden circular por un carril VAO, ¿Qué ocupación mínima debe tener el vehículo?'),
('Los accidentes de tráfico generan...'),
('El efecto submarino, que en un accidente de tráfico puede provocar graves lesiones al conductor, está relacionado con...'),
('Si queda detenido en un atasco, ¿qué distancia es aconsejable mantener con el vehículo de delante?'),
('Fuera de poblado, ¿qué separación lateral debe dejar una motocicleta al adelantar un camión?');

-- Insertar opciones para las preguntas (1 a 30)
INSERT INTO Opcion (id_pregunta, texto, es_correcta) VALUES
(1, 'No, porque podrían caerse y dificultar el manejo de los pedales.', TRUE),
(1, 'Sí, porque al no sujetar el pie, es más fácil ejercer la presión correcta sobre los pedales.', FALSE),
(1, 'Sí, porque permiten un manejo más rápido y seguro de los pedales.', FALSE),

(2, 'Sí, excepto entre la puesta y la salida de sol, porque disminuye la visibilidad.', FALSE),
(2, 'No, salvo que el cambio de sentido esté expresamente autorizado.', TRUE),
(2, 'Sí, cuando la circulación en sentido contrario lo permita.', FALSE),

(3, 'Tanto al alumno como al profesor.', FALSE),
(3, 'El alumno, ya que maneja el volante.', FALSE),
(3, 'El profesor, por ser responsable de los mandos adicionales.', TRUE),

(4, 'En cualquiera de los asientos traseros utilizando el cinturón para adultos.', FALSE),
(4, 'En un asiento delantero o trasero, utilizando siempre el cinturón de seguridad para adultos.', FALSE),
(4, 'En el asiento trasero, utilizando siempre un dispositivo de retención homologado en función de su talla y peso.', TRUE),

(5, 'Obligatoriamente a 30 km/h.', TRUE),
(5, 'Al menos a 30 km/h.', FALSE),
(5, 'A 30 km/h, como recomendación, durante el tramo que subsista el peligro.', FALSE),

(6, 'Indica la existencia de un carril especial.', FALSE),
(6, 'Sirve para delimitar, únicamente, los carriles bus.', TRUE),
(6, 'Indica el borde de la calzada.', FALSE),

(7, 'Una multa, pero sin inmovilización del vehículo.', FALSE),
(7, 'Una multa, y además se podrá inmovilizar el vehículo.', TRUE),
(7, 'La inmovilización del vehículo, pero no supone sanción económica.', FALSE),

(8, 'No, la velocidad del vehículo no tiene impacto significativo en la probabilidad de muerte de un peatón atropellado.', FALSE),
(8, 'Sí, al aumentar la velocidad de un vehículo se incrementa la probabilidad de fatalidad en caso de atropello a un peatón.', TRUE),
(8, 'La probabilidad es la misma, dependerá exclusivamente del estado de salud del peatón.', FALSE),

(9, 'Obligatoriamente uno en el lado derecho, pero pueden llevar dos.', FALSE),
(9, 'Siempre deben llevar dos espejos, uno en cada lado.', TRUE),
(9, 'Un espejo exterior izquierdo si no superan los 100 km/h y dos, uno en cada lado, si la velocidad es mayor.', FALSE),

(10, 'Sí, únicamente cuando no exista vía pecuaria.', FALSE),
(10, 'No.', TRUE),
(10, 'Sí, excepto cuando circulen en rebaño.', FALSE),

(11, 'Disminuyen el tiempo de reacción del conductor.', FALSE),
(11, 'Permiten al conductor reducir su nivel de alerta.', FALSE),
(11, 'Mejoran notablemente la seguridad activa del vehículo.', TRUE),

(12, '0,25 miligramos de alcohol por litro de aire espirado.', FALSE),
(12, '0,3 miligramos de alcohol por litro de aire espirado.', TRUE),
(12, '0,15 miligramos de alcohol por litro de aire espirado.', FALSE),

(13, 'Apagar el fuego.', FALSE),
(13, 'Sacar rápidamente a los heridos.', TRUE),
(13, 'Ir a buscar ayuda.', FALSE),

(14, 'Continuar, obedeciendo al semáforo de la derecha.', FALSE),
(14, 'Detenerse, obedeciendo al semáforo situado a la izquierda.', TRUE),
(14, 'Sólo detenerse si hay peatones cruzando.', FALSE),

(15, 'Sí, alejado se podrá apreciar mejor.', FALSE),
(15, 'Sí, debe estar al menos a 100 metros.', TRUE),
(15, 'No, se debe colocar en la parte más alta posible del vehículo inmovilizado.', FALSE),

(16, 'A la máxima velocidad permitida en la autopista.', FALSE),
(16, 'Siempre muy despacio para entrar con seguridad.', FALSE),
(16, 'A la velocidad adecuada que permita incorporarse con seguridad.', TRUE),

(17, 'La inmovilización del vehículo por necesidades de la circulación.', TRUE),
(17, 'Una parada por cualquier causa.', FALSE),
(17, 'Un estacionamiento sin bajarse del vehículo.', FALSE),

(18, 'Una vía en mal estado.', FALSE),
(18, 'Un badén en la vía.', TRUE),
(18, 'Un resalto en la vía.', FALSE),

(19, 'Por debajo de la velocidad mínima.', FALSE),
(19, 'Por encima de la velocidad máxima y por debajo de la mínima.', FALSE),
(19, 'Por encima de la velocidad mínima y por debajo de la máxima.', TRUE),

(20, 'Sí, señalizar con el intermitente derecho para indicar que puede realizar la maniobra con seguridad.', TRUE),
(20, 'No, la responsabilidad es del vehículo que adelanta.', FALSE),
(20, 'Sí, ceñirse al borde derecho de la calzada para facilitar la maniobra.', FALSE),

(21, '50 metros como mínimo.', FALSE),
(21, '50 metros si no pretende adelantar.', FALSE),
(21, 'La que le permita detenerse sin colisionar con él.', TRUE),

(22, 'Sí, siempre.', FALSE),
(22, 'Sí, si no se lleva puesto el cinturón de seguridad.', TRUE),
(22, 'No.', FALSE),

(23, 'Detenerse en las intersecciones si se acerca otro vehículo.', FALSE),
(23, 'Parar y comprobar si otro usuario de la vía tiene prioridad.', FALSE),
(23, 'No obligar al vehículo que tiene prioridad a modificar bruscamente su trayectoria o velocidad.', TRUE),

(24, 'A 30 km/h.', FALSE),
(24, 'A 20 km/h.', FALSE),
(24, 'A 50 km/h.', TRUE),

(25, 'No, la fatiga sólo produce calambres.', FALSE),
(25, 'No.', FALSE),
(25, 'Sí, por lo cual la conducción se hace más peligrosa.', TRUE),

(26, 'Dos ocupantes, incluido el conductor.', TRUE),
(26, 'Un ocupante.', FALSE),
(26, 'Dos ocupantes, sin incluir al conductor.', FALSE),

(27, 'Un enorme impacto económico, solamente.', FALSE),
(27, 'Daños materiales y costes sanitarios, administrativos y humanos.', TRUE),
(27, 'Daños materiales y costes humanos, únicamente.', FALSE),

(28, 'Una incorrecta presión de los neumáticos.', FALSE),
(28, 'Un mal uso del cinturón de seguridad.', TRUE),
(28, 'Un consumo excesivo de alcohol, medicamentos o drogas de abuso.', FALSE),

(29, 'Un metro como máximo.', FALSE),
(29, 'Un espacio mínimo para ocupar menos espacio.', FALSE),
(29, 'Dos o tres metros para no golpear al vehículo de delante en caso de alcance trasero.', TRUE),

(30, 'Una distancia proporcional a la velocidad a la que circule.', FALSE),
(30, 'Un espacio no inferior a 1,50 metros.', TRUE),
(30, 'Una separación que considere segura en función de las circunstancias del momento.', FALSE);




INSERT INTO Test (tipo_test, fecha, tiempo_limite, id_alumno) VALUES
('practica', '2025-06-01', 0, 1),
('final', '2025-06-10', 60, 2),
('practica', '2025-06-15', 0, 3),
('final', '2025-06-20', 120, 4),
('practica', '2025-06-25', 0, 5);


-- Respuestas de un alumno en un test (ejemplo)
INSERT INTO Respuesta_Alumno (id_test, id_pregunta, id_opcion_elegida, es_correcta) VALUES
(1, 1, 1, TRUE),
(1, 2, 2, TRUE),
(1, 3, 3, TRUE),
(1, 4, 3, TRUE),
(1, 5, 1, TRUE),
(1, 6, 2, TRUE),
(1, 7, 2, TRUE),
(1, 8, 2, TRUE),
(1, 9, 2, TRUE),
(1, 10, 3, TRUE),
(1, 11, 3, TRUE),
(1, 12, 2, TRUE),
(1, 13, 2, TRUE),
(1, 14, 2, TRUE),
(1, 15, 3, TRUE),
(1, 16, 3, TRUE),
(1, 17, 1, TRUE),
(1, 18, 2, TRUE),
(1, 19, 3, TRUE),
(1, 20, 1, TRUE),
(1, 21, 3, TRUE),
(1, 22, 2, TRUE),
(1, 23, 1, TRUE),
(1, 24, 3, TRUE),
(1, 25, 3, TRUE),
(1, 26, 1, TRUE),
(1, 27, 3, TRUE),
(1, 28, 3, TRUE),
(1, 29, 3, TRUE),
(1, 30, 2, TRUE);




INSERT INTO Clase_Practica (fecha, hora, examen, apto_examen, comentario, id_alumno, id_instructor, estado) VALUES
('2025-06-01', '10:00:00', FALSE, NULL, 'Clase de manejo en ciudad', 1, 1, 'pendiente'),
('2025-06-02', '12:00:00', FALSE, NULL, 'Clase en carretera', 2, 2, 'pendiente');


INSERT INTO Notificacion (id_clase, tipo, mensaje, destinatario) VALUES
(1, 'reserva', 'Clase de práctica reservada para el 1 de junio a las 10:00', 'carlos.gomez@email.com'),
(2, 'reserva', 'Clase de práctica reservada para el 2 de junio a las 12:00', 'ana.perez@email.com');
