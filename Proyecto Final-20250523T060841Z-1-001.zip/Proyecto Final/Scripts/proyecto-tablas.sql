CREATE TABLE Alumno (
  id_alumno INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL,
  apellido VARCHAR(50) NOT NULL,
  telefono VARCHAR(20),
  correo VARCHAR(100) NOT NULL
);

CREATE TABLE Instructor (
  id_instructor INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL,
  apellido VARCHAR(50) NOT NULL,
  telefono VARCHAR(20),
  correo VARCHAR(100) NOT NULL
);

CREATE TABLE Test (
  id_test INT AUTO_INCREMENT PRIMARY KEY,
  tipo_test ENUM('practica', 'final') NOT NULL,
  fecha DATE NOT NULL,
  tiempo_limite INT DEFAULT 0,  
  id_alumno INT NOT NULL,
  FOREIGN KEY (id_alumno) REFERENCES Alumno(id_alumno)
);

CREATE TABLE Pregunta (
  id_pregunta INT AUTO_INCREMENT PRIMARY KEY,
  enunciado TEXT NOT NULL
);


CREATE TABLE Opcion (
  id_opcion INT AUTO_INCREMENT PRIMARY KEY,
  id_pregunta INT NOT NULL,
  texto TEXT NOT NULL,
  es_correcta BOOLEAN NOT NULL,
  FOREIGN KEY (id_pregunta) REFERENCES Pregunta(id_pregunta)
);


CREATE TABLE Respuesta_Alumno (
  id_test INT,
  id_pregunta INT,
  id_opcion_elegida INT,
  es_correcta BOOLEAN,
  PRIMARY KEY (id_test, id_pregunta),
  FOREIGN KEY (id_test) REFERENCES Test(id_test) ON DELETE CASCADE,
  FOREIGN KEY (id_pregunta) REFERENCES Pregunta(id_pregunta),
  FOREIGN KEY (id_opcion_elegida) REFERENCES Opcion(id_opcion)
);

CREATE TABLE Clase_Practica (
  id_clase INT AUTO_INCREMENT PRIMARY KEY,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  examen BOOLEAN DEFAULT FALSE,  -- indica si es clase simulacro de examen
  apto_examen BOOLEAN,          -- NULL = no evaluado aún
  comentario TEXT,
  id_alumno INT NOT NULL,
  id_instructor INT NOT NULL,
  estado ENUM('pendiente', 'completada', 'cancelada') DEFAULT 'pendiente',
  FOREIGN KEY (id_alumno) REFERENCES Alumno(id_alumno),
  FOREIGN KEY (id_instructor) REFERENCES Instructor(id_instructor)
);


CREATE TABLE Notificacion (
  id_notificacion INT AUTO_INCREMENT PRIMARY KEY,
  id_clase INT NOT NULL,
  tipo ENUM('reserva', 'cancelacion') NOT NULL,
  mensaje TEXT NOT NULL,
  fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
  via ENUM('correo', 'sms', 'ambos') DEFAULT 'correo',
  destinatario VARCHAR(50),  -- puede ser correo electrónico del receptor
  FOREIGN KEY (id_clase) REFERENCES Clase_Practica(id_clase)
);
